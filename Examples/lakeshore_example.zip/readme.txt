Here are the explanatory for the three examples.

1_lakeshore_example_original ArcNLET_NO3

    This example aligns with the lakeshore example from the VB.NET version of the ArcNLET model. It uses the groundwater module, particle
    tracking module, transport module, and load estimation module to estimate the load of NO3-N from groundwater to surface water. NH4-N
    and vadose zone processes are not included in this example.


2_lakeshore_example_ArcNLET-Py_NO3+NH4

    This example is the lakeshore example using all six modules of ArcNLET-Py to estimate the loads of NO3-N and NH4-N from groundwater to 
    surface water, incorporating vadose zone and groundwater processes but excluding phosphate modelling. 


3_lakeshore_example_ArcNLET-Py_NO3+NH4+PO4

    This example is similar to the previous example, but includes phosphate modelling.



Each example contains multiple subfolders, numbered to correspond with the steps in that example. For instance, folder 2 in example 1, representing
the particle tracking module, corresponds to the second step. It's important to open the folders in sequence, as the results from previous modules 
are required for subsequent steps. Within each subfolder, you'll find additional subfolders for inputs and outputs, containing the files used and 
generated for that step. A screenshot of the module setup, showing all the settings and parameters used to run the module, is also included.
The red boxes identify the parameters that were modified, those not identified are the default values.



