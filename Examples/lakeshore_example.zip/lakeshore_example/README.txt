There are three folders in lakeshore example.

0_Original_data
1_lakeshore_example_simple
2_lakeshore_example_complex


The first folder 0_Original_data contains the orginal data files downloaded from public websites. 
The second folder 1_lakeshore_example_simple contains a simple example using only 4 modules. This example is exactly the same as the lakeshore example in the old VB.net version of ArcNLET in ArcMap.
The third folder 2_lakeshore_example_complex contains a more complex example using all modules of ArcNLET-Py, which calculates both NH4-N and NO3-N in soil and groundwater.


In each subfolder of 1_lakeshore_example_simple and 2_lakeshore_example_complex, there are two folders, "Inputs" and "Outputs", which hold the input and output files for the corresponding module. There is also a screenshot of the tool to show the parameters used.


Date : 4/25/2024