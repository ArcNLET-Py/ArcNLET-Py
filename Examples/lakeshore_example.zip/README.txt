There are two folders in lakeshore example.

0_lakeshore_example_simple
1_lakeshore_example_complex


The first folder 0_lakeshore_example_simple contains a simple example using only 4 modules, which calculates only  NO3-N pollution in groundwater. This example is exactly the same as the lakeshore example in the old VB.net version of ArcNLET.
The second folder 1_lakeshore_example_complex contains a more complex example using all modules of ArcNLET-Py, which calculates both NH4-N and NO3-N in soil and groundwater.

In each subfolder of 0_lakeshore_example_simple and 1_lakeshore_example_complex, the files are organized according to ArcNLET-Py's modules. Under the folder of each module, there are two subfolders, "Inputs" and "Outputs", which hold the input and output files for the corresponding module. There is also a screenshot of the tool to show the parameters used.


Date : 4/25/2024